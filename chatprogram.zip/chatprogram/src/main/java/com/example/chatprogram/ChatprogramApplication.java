package com.example.chatprogram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatprogramApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChatprogramApplication.class, args);
    }

}
